/*
 * array.h
 *
 *  Created on: 15-dic-2009
 *      Author: Veronica
 */

void inizializza(int vettore[], int dim)
{
        int i;
        for (i=0; i<dim; i++)
        {
          printf("\nInserire il %d valore --> ", (i+1));
          scanf("%d", &vettore[i]);
        }
}

void visualizza(int vettore[], int dim)
{
        int i;
        for (i=0; i<dim; i++)
        {
           printf("Il %d valore e' --> %d\n", (i+1), vettore[i]);
        }
}
int valore_massimo(int vettore[], int dim)
{
        int i, massimo_corrente;
        massimo_corrente=vettore[0];
        for (i=1; i<dim; i++)
        {
           if (vettore[i]>massimo_corrente)
              massimo_corrente=vettore[i];
        };
        return(massimo_corrente);
}
int valore_minimo(int vettore[], int dim)
{
        int i, minimo_corrente;
        minimo_corrente=vettore[0];
        for (i=1; i<dim; i++)
        {
           if (vettore[i]<minimo_corrente)
              minimo_corrente=vettore[i];
        };
        return(minimo_corrente);
}


void ordina_vettore(int vettore[], int dim)
{

        int i, temp, posizione;
        for (i=0; i<dim; ++i)
        {
            posizione=valore_minimo(vettore, dim);
            temp=vettore[i];
            vettore[i]=vettore[posizione];
            vettore[posizione]=temp;
        }
}

/*
 * HelloWorld.c
 *
 *  Created on: 06/nov/2009
 *      Author: Acer
 *
 *    Questo programma attende che l'utente digiti un qualunque tasto sulla tastiera
 *    prima di chiudere la finestra di esecuzione
 */

#include <stdio.h>
#include <stdlib.h>
int main ()
{
     printf("Hello world \n\n");
     system ("pause");
     return 0;
}

/*
 * MediaInt.c
 *
 *  Created on: 4-nov-2009
 *      Author: Veronica
 */
#include <stdio.h>
int main ()
{
     int a, b, media; /*definizione delle variabili locali al main*/
     a=6;
     b=10;
     media=(a+b)/2;
     printf("Media tra 6 e 10: %d ", media);
     return 0;
}


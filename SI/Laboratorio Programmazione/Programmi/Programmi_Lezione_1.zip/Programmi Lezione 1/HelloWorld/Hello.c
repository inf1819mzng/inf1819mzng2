/*
 * Hello.c
 *
 *  Created on: 27/ott/2009
 *      Author: Acer
 *  Il programma stampa a video la stringa "Hello world"
 *  se lo si esegue direttamente dal prompt non si vedr� nulla
 *  poich� non vi � un'istruzione di attesa
  */

#include <stdio.h>
int main ()
{

     printf("Hello world");
     return 0;
}
